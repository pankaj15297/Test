class MeController < ApplicationController
end
