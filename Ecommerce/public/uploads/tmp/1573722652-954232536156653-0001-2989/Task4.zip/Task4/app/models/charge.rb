class Charge < ApplicationRecord
end
