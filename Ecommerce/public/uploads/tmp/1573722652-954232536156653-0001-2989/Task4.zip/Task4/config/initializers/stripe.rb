# Rails.configuration.stripe = {
# pk_test_1pTn49vuq0ZArUMntIGzmq2C00akfrDicZ: Rails.application.secrets.stripe_publishable_key,
# sk_test_SAQYyEYJtclyZoMHIV5pyxe600T7hHHKa5:      Rails.application.secrets.stripe_secret_key
# }
# Stripe.api_key = Rails.configuration.stripe[:secret_key]


Rails.configuration.stripe = {
  publishable_key: Rails.application.secrets.stripe_publishable_key,
  secret_key:      Rails.application.secrets.stripe_secret_key
}

Stripe.api_key = Rails.configuration.stripe[:secret_key]