Rails.application.config.middleware.use OmniAuth::Builder do
  provider :google_oauth2, "394895784987-gh80f9m5fkubghdme1lfbidlisl8150g.apps.googleusercontent.com", "w1WF8qwTmb4xl6vKubqccWsS"
end